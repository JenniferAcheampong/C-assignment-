﻿namespace Assignment_01_Iamkwame.Models
{
    public class Class
    {
    }
}
